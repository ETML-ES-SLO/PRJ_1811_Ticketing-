mettre les dossiers au niveau de:
C:\microchip\harmony\v1_08_01\apps\

logiciels 
MPLABX 3.40
xc32 1.42
Harmony 1.08

Auteur:
simonet yoann
16.06.2017

remarque:
Les codes Tx et Rx sont seux utilis� dans le projet 
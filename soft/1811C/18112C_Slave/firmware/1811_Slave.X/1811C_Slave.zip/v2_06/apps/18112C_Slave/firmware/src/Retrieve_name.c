/******************************************************************************/
// Project		: 2126 Affichage Matriciel Nom Etudiant
// Author 		: Ricardo Crespo
// Date 		: 12.06.2022
// Descrition   : Fichier du code principal
//
//  Modification: Mario Dos Santos
//  Date        : 31.08.2022
//  Description : Modifier le fichier pour n'avoir que la partie lecture de nom.
//                pour pouvoir l'utiliser dans le projet 1811C Ticketing 
//                (Supprimer la partie Matrix et I2C)
//
/******************************************************************************/

/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    Retrive_Name.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "Retrieve_name.h"                       
#include "app.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************


uint8_t countCar = 0;           // Compteur du nombre de characters d'un nom
char buffReadName[20] = {' '};// Buffer de reception de l'UART
uint8_t Name_Receive = false;   //Flag Nom recu

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

    
// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************


/******************************************************************************
  Function:
    void Retrive_Name ( void )

  Remarks:
    See prototype in Retrive_Name.h.
 */
void Retrive_Name ( void )
{
    
    static uint8_t numberChar = 0;       // Compteur de la taille de la cl� d'envoi

    char key[] = {'C', '\0'};            // Cl� de confirmaiton pour le software
    char keyCom = 'x';                   // Cl� de communication de la part du software
    char keyEndName[] = {'X', 'D', 'R'}; // Cl� de fin de nom complet
    char character;                      // Buffeur du character actuellement lu
    char reciveCharacter = ' ';          // Buffeur de r�ception des caracteres de l'UART
    
    static bool startReadName = false;   // Permet de commencer � lire le nom
    

  

    
    // Tant que l'on re�ois des datas dans le RX buffeur ET pas l'animation 
    while(PLIB_USART_ReceiverDataIsAvailable(USART_ID_2))
    {
        // R�cup�ration du charactere dpuis le RX buffeur
       
        character = PLIB_USART_ReceiverByteReceive(USART_ID_2);
        

        // Si on a pas re�u la cl� de communication et qu'on a pas encore lu le nom 
        if((character != keyCom) && (!startReadName))
        {
            // Reset du compteur du nombre de characteres du nom
            countCar = 0;
            // Peut d�marer la lecture du nom complete
            startReadName = true;
        }
        // Si non on stoque la cl� de communicaiton avec le software
        else
        {
            // Sauvegarde de la cl� de communicaiton avec le software
            reciveCharacter = character;
        }

        // Si on peut faire la lecture du nom complete
        if(startReadName)
        {
            // Stockage du charactere actuel dans le buffer de stockage du nom
            buffReadName[countCar] = character;
            // Incr�mentation du nombre de characteres du nom
            countCar++;
        }
    }

    // Si on a re�u la cl� du Software ET que l'on lit pas le nom
    if((reciveCharacter == keyCom) && !startReadName)
    {
        // Tant qu'on a pas fini la chaine ET que l'on a pas plus de 8 caracteres
        while ((key[numberChar] != 0) && (numberChar < SIZE_KEY)) 
        {
            // Attent que le TX buffeur soit disponible
            while(PLIB_USART_TransmitterBufferIsFull(USART_ID_2));
            // Envoi de la cl� de confirmation au software
            PLIB_USART_TransmitterByteSend(USART_ID_2, key[numberChar]);
            // Incr�mentation du compteur de nombre de characteres
            numberChar++;
        }
        // Reset du beuffer de r�ception des characteres
        reciveCharacter = ' ';
        // Reset du compteur de nombre de characteres
        numberChar = 0;
    } 

    // Si on a re�u un nom d'�l�ve et qu'on a pas encore d'annimation
    if((buffReadName[0] != 0x20)
    && (buffReadName[0] != NULL)
    && (buffReadName[0] != keyCom)
    && (buffReadName[countCar - 3] == keyEndName[0])
    && (buffReadName[countCar - 2] == keyEndName[1])
    && (buffReadName[countCar - 1] == keyEndName[2]))
    {
        // Enl�ve les position de la cl� de r�ception du nom 
        countCar -= (END_NAME_KEY_SIZE - 1);
        // Ins�re un '.' apr�s la lettre maguscule du nom de l'�l�ve

    }

}

/*******************************************************************************
 End of File
 */
